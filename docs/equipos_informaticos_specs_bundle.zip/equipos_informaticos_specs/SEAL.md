# SEAL — Sello del bundle

**Fecha:** 2026-01-28  
**Bundle:** SOURCE_POLICY.md + SPIDER_SCOPE.md  
**SHA-256 (referencia):** `163ca342cff9e636a1f9c2433e08d6d08b91cfed98a7fee35af8020bf8254d3e`

Nota: este hash es el sello de integridad del par de documentos “SEALED v1.0”.
Si se modifica cualquier contenido, debe generarse un nuevo hash y versionar.
